namespace Product 
{
    public interface IProduct 
    {
        public int getValue();
    }
}